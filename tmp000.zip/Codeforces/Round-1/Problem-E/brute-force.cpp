#include <bits/stdc++.h>

#define rep(i, s, e) for(int i = s; i <= (e); ++i)
#define fep(i, s, e) for(int i = s; i < (e); ++i)
#define _rep(i, s, e) for(int i = s; i >= (e); --i)
#define _fep(i, s, e) for(int i = s; i > (e); --i)

// #define int long long
#define pii pair<int, int>

namespace FastIO {
	template <typename _Tp> inline void read(_Tp &x) { int neg = 1; char ch; while(ch = getchar(), !isdigit(ch)) if(ch == '-') neg = -1; x = ch - '0'; while(ch = getchar(), isdigit(ch)) x = (x << 3) + (x << 1) + (ch ^ '0'); x *= neg; }
	template <typename _Tp, typename... _Args> inline void read(_Tp &x, _Args &...args) { read(x); read(args...); }
	template <typename _Tp> inline void read(_Tp* begin, _Tp* end) { int len = end - begin; for(int i = 0; i < len; ++i) read(*(begin + i)); }
	template <typename _Tp> inline void write(_Tp x) { if(x < 0) putchar('-'), x= -x; if(x > 9) write(x / 10); putchar(x % 10 + '0'); }
	template <typename _Tp, typename... _Args> inline void write(_Tp x, _Args ...args) { write(x); putchar(' '); write(args...); }
	template <typename _Tp> inline void write(_Tp* begin, _Tp* end) { int len = end - begin; for(int i = 0; i < len; ++i) write(*(begin + i)), putchar(' '); }
}

using namespace std;
using namespace FastIO;

constexpr int inf = numeric_limits<int>::max() / 2;
constexpr int ninf = numeric_limits<int>::min() / 2;
constexpr int mod = 998244353;
constexpr double eps = 1e-9;

int n, a[1000005], b[1000005], c[1000005], vis[1000005], ans;

void solve() {
	read(n);
	rep(i, 1, n) {
		read(a[i], b[i]);
	}
	ans = 0;
	fep(st, 0, 1 << n) {
		rep(i, 1, n) {
			if((st >> (i - 1) & 1)) {
				c[i] = a[i];
			} else {
				c[i] = b[i];
			}
			vis[c[i]] = 1;
		}
		rep(i, 0, n) {
			if(not vis[i]) {
				ans = max(ans, i);
				break;
			}
		}
		rep(i, 1, n) {
			vis[c[i]] = 0;
		}
	}
	write(ans);
	putchar('\n');
	return;
}

signed main() {
	int T = 1; read(T);
	while(T--) solve();
	return 0;
}