#include <bits/stdc++.h>

#define rep(i, s, e) for(int i = s; i <= (e); ++i)
#define fep(i, s, e) for(int i = s; i < (e); ++i)
#define _rep(i, s, e) for(int i = s; i >= (e); --i)
#define _fep(i, s, e) for(int i = s; i > (e); --i)

// #define int long long
#define pii pair<int, int>

namespace FastIO {
	template <typename _Tp> inline void read(_Tp &x) { int neg = 1; char ch; while(ch = getchar(), !isdigit(ch)) if(ch == '-') neg = -1; x = ch - '0'; while(ch = getchar(), isdigit(ch)) x = (x << 3) + (x << 1) + (ch ^ '0'); x *= neg; }
	template <typename _Tp, typename... _Args> inline void read(_Tp &x, _Args &...args) { read(x); read(args...); }
	template <typename _Tp> inline void read(_Tp* begin, _Tp* end) { int len = end - begin; for(int i = 0; i < len; ++i) read(*(begin + i)); }
	template <typename _Tp> inline void write(_Tp x) { if(x < 0) putchar('-'), x= -x; if(x > 9) write(x / 10); putchar(x % 10 + '0'); }
	template <typename _Tp, typename... _Args> inline void write(_Tp x, _Args ...args) { write(x); putchar(' '); write(args...); }
	template <typename _Tp> inline void write(_Tp* begin, _Tp* end) { int len = end - begin; for(int i = 0; i < len; ++i) write(*(begin + i)), putchar(' '); }
}

using namespace std;
using namespace FastIO;

constexpr int inf = numeric_limits<int>::max() / 2;
constexpr int ninf = numeric_limits<int>::min() / 2;
constexpr int mod = 998244353;
constexpr double eps = 1e-9;

mt19937 rnd(random_device{}());
int T = 1, cnt;
bool vis[1000005];
pii c[1000005];

signed main() {
	write(T);
	putchar('\n');
	while(T--) {
		int n = 20;
		rep(i, 1, n) {
			vis[i] = 0;
		}
		cnt = rnd() % (n + 1);
		while(cnt--) {
			vis[rnd() % n + 1] = 1;
		}
		rep(i, 1, n) {
			if(vis[i]) {
				c[++cnt] = {i, rnd() % i};
			}
		}
		while(cnt < n) {
			c[++cnt] = {rnd() % (n + 1), rnd() % (n + 1)};
		}
		rep(i, 1, n) {
			if(rnd() & 1) {
				swap(c[i].first, c[i].second);
			}
		}
		shuffle(c + 1, c + 1 + n, rnd);
		write(n);
		putchar('\n');
		rep(i, 1, n) {
			write(c[i].first);
			putchar(' ');
			write(c[i].second);
			putchar('\n');
		}
	}
	return 0;
}